package testing;

import javabean.Producto;

public class TestProducto {

	public static void main(String[] args) {
		
		//Creamos el producto1 usando el constructor vacio y ponemos los valores.
		Producto producto1 = new Producto();
		
		//Usamos los setters para el producto1
		producto1.setCodigoBarras(5863749812036L);
		producto1.setDescripcion("Camiseta");
		producto1.setPrecioUnitario(15.00);
		producto1.setCantidadStock(20);
		producto1.setTalla("S");
		producto1.setColor("Rojo");
		
		
		//Testeamos los metodos.
		
		//Metodo solicitado 1.
		System.out.println("el valor inicial es : " + producto1.getPrecioUnitario() + "\n");
		System.out.println("El precio con IVA es: " + producto1.precioConIva(21) + "\n");
		
		//Metodo solicitado 2.
		System.out.println("La cantidad del stock actual es : " + producto1.getCantidadStock() + "\n");
		producto1.aumentarStock(10);
		System.out.println("El stock ha aumentado el nuevo stock es : " + producto1.getCantidadStock() + "\n");
		
		//metodo solicitado 3.
		System.out.println("El stock actual es : " + producto1.getCantidadStock() + "\n");
		producto1.disminuirStock(10);
		System.out.println("El stock ha disminuido : " + producto1.getCantidadStock());
		
		System.out.println("la Talla es: " + producto1.getTalla());
		System.out.println("el precio aplicado es : " + producto1.precioAplicado());
		
		Producto producto2 = new Producto(7841260987103L, "Pantalon", 20.00, 30, "XXL", "Negro");
		
		//Metodo solicitado 1.
				System.out.println("el valor inicial es : " + producto1.getPrecioUnitario() + "\n");
				System.out.println("El precio con IVA es: " + producto1.precioConIva(21) + "\n");
				
				//Metodo solicitado 2.
				System.out.println("La cantidad del stock actual es : " + producto1.getCantidadStock() + "\n");
				producto2.aumentarStock(10);
				System.out.println("El stock ha aumentado el nuevo stock es : " + producto1.getCantidadStock() + "\n");
				
				//metodo solicitado 3.
				System.out.println("El stock actual es : " + producto2.getCantidadStock() + "\n");
				producto2.disminuirStock(41);
				if(producto2.cantidadStock() == false) {
					System.out.println("el stock no puede ser por debajo de cero");
				}
				System.out.println("El stock ha disminuido : " + producto2.getCantidadStock());
				
				System.out.println("la Talla es: " + producto2.getTalla());
				System.out.println("el precio aplicado es : " + producto2.precioAplicado());
		
		

	}
	
}
